import sys, pygame
from pygame.sprite import LayeredUpdates
from collections import namedtuple
import random 
import time
from player import *
from deck import *
from graph import *
from build import *
import build
import graph
import player
import deck
import Resource



#Setting all the constants for pygame map and GUI class
#reason for Courier New: http://dyslexiahelp.umich.edu/sites/default/files/good_fonts_for_dyslexia_study.pdf
MAP_WIDTH = 711
BAR_WIDTH = 200
BUTTON_HEIGHT = 50
CENTER = 100
pygame.font.init()
FONT_SIZE = 16
BIG_FONT_SIZE = 42
FONT = pygame.font.SysFont("Courier New", FONT_SIZE)
BIG_FONT = pygame.font.SysFont("Courier New", BIG_FONT_SIZE)
BIG_FONT.set_bold(True)
PAD = 6
RETICLE_RATE = 0.02
PLAYER_NAME = {
        0: "Player A",
        1: "Player B",
        2: "Player C",
        3: "Player D"

}
FONT_COLOUR = (0, 0, 0)
BAR_COLOUR = (150, 150, 150)
OUTLINE_COLOUR = (50, 50, 50)
BUTTON_HIGHLIGHT_COLOUR = (255, 255, 255)
BUTTON_DISABLED_COLOUR = (64, 64, 64)



#class for modes to be set
class Modes:
        Roll, RollDisplay, Action, Trade, ResSel1, ResSel2, ValSel1, ValSel2, YesNo, Build, BuildRoad, RoadInter, BuildCity, BuildSettlement, BuildCard, UseCard, DrawCard, InvtCheck, Plenty, Monopoly, GameOver = range(21)



Button = namedtuple('Button', ['slot', 'text', 'onClick', 'condition'])

class GUI(LayeredUpdates):

        numberOfInstances = 0
        resourceCoords = []

      

        def __init__(self, screenRectangle, backgroundColour):
                
                LayeredUpdates.__init__(self) 
                if GUI.numberOfInstances != 0:
                        raise Exception("GUI: One game at a time please!")
                GUI.numberOfInstances = 1 

                #buttons for keeping track of turn stats for modes
                self.turn = {eachPlayer: 0 for eachPlayer in PLAYER_NAME}
                self.currentPlayer = 0 # player index, start with A
                self.dice = 0
                self.value = 0
                self.playerList = {eachPlayer: Player(eachPlayer) for eachPlayer in PLAYER_NAME}

                #List of roads for each player, active cities for drawing display
                self.road0 = list()
                self.road1 = list()
                self.road2 = list()
                self.road3 = list()
                self.activesettlements = dict()
                self.activecities = dict()
                self.activeNodes = list()

                #creates deck and active
                self.deck = Deck()
                self.deck.shuffle()
                self.cardflag = 0

                #creates pygame screen and set
                self.screen = pygame.display.set_mode((screenRectangle.w, screenRectangle.h))
                self.screenRectangle = screenRectangle

                self.buildPackage = {'type': None, 'x': None, 'y': None}
                self.board = pygame.image.load('board.jpg')
                self.barRectangle = pygame.Rect(screenRectangle.w - BAR_WIDTH,
                                                                        0,
                                                                        BAR_WIDTH,
                                                                        screenRectangle.h)
                self.viewRectangle = pygame.Rect(0, 
                                                                         0, 
                                                                         MAP_WIDTH,
                                                                         screenRectangle.h)
                self.backgroundColour = backgroundColour
                self.map = None


                
                self.tradeHolder1 = {'resourceType': None, 'number': 0}
                self.tradeHolder2 = {'resourceType': None, 'number': 0}


                self.numberPlayers = 2 # always four players for now
                self.numberTurns = 0
                self.winningPlayer = None

                self.rollButton = Button(0, "Roll Dice", self.rollOnClick, None)
                self.okayButton = Button(0, "Sounds good!", self.backToAction, None)


                ##from here until next comment is making the button lists for each and every possible screen for the players to interact with##
                                #Each button has to have its own method for actions. Which is.. almost egregious for how much code it takes. But okay.#
                self.buttons = [ 
                #struct of button args: 'slot', 'text', 'onClick', 'condition'
                Button(0, "End Turn", self.endTurn, None), 
                Button(1, "Build", self.buildStart, self.hasStarted), 
                Button(2, "Trade", self.proposeTrade, self.hasStarted),
                Button(4, "Card", self.cardmode, self.canBuildCard),
                Button(3, "Inventory", self.checkInventory, None)

                ]

                self.tradewith = [
                        Button(0, 'Go Back', self.backToAction, None),
                        Button(4, 'Player A', self.tradeWithA, self.canTradeA),
                        Button(3, 'Player B', self.tradeWithB, self.canTradeB),
                        Button(2, 'Player C', self.tradeWithC, self.canTradeC),
                        Button(1, 'Player D', self.tradeWithD, self.canTradeD),
                ]

                self.resources1 = [ 
                        Button(0, 'Wood', self.tradewood1, None),
                        Button(1, 'Wheat', self.tradewheat1, None),
                        Button(2, 'Brick', self.tradebrick1, None),
                        Button(3, 'Sheep', self.tradesheep1, None),
                        Button(4, 'Ore', self.tradeore1, None)
                ]

                self.resources2 = [
                        Button(0, 'Wood', self.tradewood2, None),
                        Button(1, 'Wheat', self.tradewheat2, None),
                        Button(2, 'Brick', self.tradebrick2, None),
                        Button(3, 'Sheep', self.tradesheep2, None),
                        Button(4, 'Ore', self.tradeore2, None)
                ]

                self.numbers1 = [ 
                Button(2, 'More', self.up1, self.TradeValueMore1), 
                Button(1, 'Less', self.down1, self.greaterThanZero),
                Button(0, 'Done', self.done1, self.greaterThanZero)
                ]

                self.numbers2 = [ 
                Button(2, 'More', self.up1, self.TradeValueMore2), 
                Button(1, 'Less', self.down1, self.greaterThanZero),
                Button(0, 'Done', self.done2, self.greaterThanZero)
                ]

                self.construction = [ # list of buttons of items one can build
                Button(0, "Go Back", self.backToAction, self.hasStarted),
                Button(1, 'Road', self.buildRoad, self.canBuildRoad),
                Button(2, 'Settlement', self.buildSettlement, self.canBuildSettlement),
                Button(3, 'City', self.buildCity, self.canBuildCity),
                ]

                self.yesno = [ # yes or no!
                        Button(0, "NAY!", self.noway, None),
                        Button(1, "YAY!", self.yesway, None) # add conditions for yes?
                ]

                self.cardChoices = [
                Button(0, "Go Back", self.backToAction, None),
                Button(1, "Buy (draw)", self.buyCard, self.canBuyCard), 
                Button(2, "Use", self.useCard, self.hasCard)]

                self.usecards = [
                Button(0, "Go Back", self.backToAction, None),
                Button(1, "World Wonder", self.useWonder, self.hasWonder),
                Button(2, "Road Builder", self.useRoadBuilder, self.hasRoadBuilder),
                Button(3, "Knight", self.useKnight, self.hasKnight),
                Button(4, "Year of Plenty", self.useYearofPlenty, self.hasYearOfPlenty),
                Button(5, "Monopoly", self.useMonopoly, self.hasMonopoly)
                ]

                self.plentyButtons = [
                Button(0, "Wheat", self.plentywheat, None),
                Button(1, "ore", self.plentyore, None), 
                Button(2, "Brick", self.plentybrick, None),
                Button(3, "Wood", self.plentywood, None),
                Button(4, "Sheep", self.plentysheep, None)]

                self.monopoly_buttons = [
                Button(0, "Wheat", self.monopolywheat, None),
                Button(1, "ore", self.monopolyore, None),
                Button(2, "Brick", self.monopolybrick, None),
                Button(3, "Wood", self.monopolywood, None),
                Button(4, "Sheep", self.monopolysheep, None)]

                self.gameOver = Button(0, "Exit", self.gtfo, None)
                
                for player in self.playerList:
                        self.playerList[player].wheat = 10
                        self.playerList[player].ore = 10
                        self.playerList[player].brick = 10
                        self.playerList[player].sheep = 10
                        self.playerList[player].wood = 10

                

                self.mode = Modes.Build


                self.largestArmy = None
                self.longestRoad = 4
                self.longestRoad2 = None
                self.longestRoadLength = 0



  
        #Checks to see if we're past the first two turns for loading appropriate menu
        def hasStarted(self):
                if self.turn[self.currentPlayer] < 2:
                        return False
                return True


        #sets mode to inventory check
        def checkInventory(self):
                self.mode = Modes.InvtCheck

        #sees if player can acquire card
        def canBuildCard(self):
                if len(self.playerList[self.currentPlayer].cards) == 0:

                        return self.canBuyCard()
                else:
                        return True

        #set back to turn action mode
        def backToAction(self):
                self.mode = Modes.Action

        #Roll the dice for a number
        def rollOnClick(self):

                dice1 = random.randint(1, 6)
                dice2 = random.randint(1, 6)
                self.dice = dice1 + dice2

         
                return self.dice

        #player has resources to buy card?
        def canBuyCard(self):
                return (self.playerList[self.currentPlayer].wheat >= 1 and 
                           self.playerList[self.currentPlayer].ore >=1 and 
                           self.playerList[self.currentPlayer].sheep >= 1)

        #can player build road?
        def canBuildRoad(self):
                if not self.hasStarted():
                        return False
                elif self.playerList[self.currentPlayer].brick > 0 and \
                         self.playerList[self.currentPlayer].wood > 0:
                         return True

        #Player has cards? Good
        def hasCard(self):
                if len(self.playerList[self.currentPlayer].cards) > 0:
                        return True

                return False

        def TradeValueMore1(self):
                if self.tradeHolder1['resourceType'] == 'ore':
                        return self.playerList[self.currentPlayer].ore > self.value
                elif self.tradeHolder1['resourceType'] == 'wheat':
                        return  self.playerList[self.currentPlayer].wheat > self.value
                elif self.tradeHolder1['resourceType'] == 'wood':
                        return self.playerList[self.currentPlayer].wood > self.value
                elif self.tradeHolder1['resourceType'] == 'sheep':
                        return self.playerList[self.currentPlayer].sheep > self.value
                elif self.tradeHolder1['resourceType'] == 'brick':
                        return self.playerList[self.currentPlayer].brick > self.value

        def TradeValueMore2(self):
                if self.tradeHolder2['resourceType'] == 'ore':
                        return self.playerList[self.sendTo].ore > self.value
                elif self.tradeHolder2['resourceType'] == 'wheat':
                        return  self.playerList[self.sendTo].wheat > self.value
                elif self.tradeHolder2['resourceType'] == 'wood':
                        return self.playerList[self.sendTo].wood > self.value
                elif self.tradeHolder2['resourceType'] == 'sheep':
                        return self.playerList[self.sendTo].sheep > self.value
                elif self.tradeHolder2['resourceType'] == 'brick':
                        return self.playerList[self.sendTo].brick > self.value

        def tradeWithA(self):
                self.sendTo = 0
                self.mode = Modes.ResSel1

        def tradeWithB(self):
                self.sendTo = 1
                self.mode = Modes.ResSel1

        def tradeWithC(self):
                self.sendTo = 2
                self.mode = Modes.ResSel1

        def tradeWithD(self):
                self.sendTo = 3
                self.mode = Modes.ResSel1

        def endTurn(self):
                self.mode = Modes.Roll
                self.turn[self.currentPlayer] += 1
                if self.currentPlayer is 3:
                        self.currentPlayer = 0
                else:
                        self.currentPlayer += 1

                if self.hasStarted():
                        self.mode = Modes.Roll
                else:
                        self.mode = Modes.Build
                if self.largestArmy != self.currentPlayer:
                        self.largestArmy = findLargestArmy(self.currentPlayer, self.largestArmy, self.playerList)


                # player 1
                if self.currentPlayer == 0:
                        self.longestRoadLength = longestRoad(self.road0)
                # player 2
                if self.currentPlayer == 1:
                        self.longestRoadLength = longestRoad(self.road1)
                # player 3
                if self.currentPlayer == 2:
                         self.longestRoadLength = longestRoad(self.road2)
                #player 4
                if self.currentPlayer == 3:
                        self.longestRoadLength = longestRoad(self.road3)

                if self.longestRoadLength > self.longestRoad:
                        self.longestRoad = self.longestRoadLength
                        if self.longestRoad2 == None:
                                self.playerList[self.currentPlayer].victoryPoints += 2
                                self.longestRoad2 = self.currentPlayer
                        else:
                                self.playerList[self.currentPlayer].victoryPoints += 2
                                self.playerList[self.longestRoad2].victoryPoints -= 2


                if self.playerList[self.currentPlayer].victoryPoints >= 10:
                        self.mode = Modes.GameOver
                



        


        #mode sets for building roads
        def buildStart(self):
                self.mode = Modes.Build

        def buildRoad(self):
                self.mode = Modes.BuildRoad
                self.buildPackage['type'] = 'road'

        def buildCity(self):
                self.mode = Modes.BuildCity
                self.buildPackage['type'] = 'city'

        #tells if player can build city
        def canBuildCity(self):
                player = self.playerList[self.currentPlayer] 
                if not self.hasStarted():
                        return False
                elif player.settlements > 0 and player.ore > 2 and \
                         player.wheat > 1:
                         return True
                else:
                        return False

        #tells if player can build settlement
        def canBuildSettlement(self):
                player = self.playerList[self.currentPlayer] 
                if not self.hasStarted():
                        return True
                elif player.brick > 0 and player.wheat > 0 and player.wood > 0 \
                         and player.sheep > 0:
                         return True
                else:
                        return False

        def buildSettlement(self):
                self.mode = Modes.BuildSettlement
                self.buildPackage['type'] = 'settlement'

                '''
                #handled elsewhere now, leaving this in case needed
                if not self.hasStarted():
                        self.mode = Modes.BuildRoad
                '''





        #gives player card
        def buyCard(self):

                self.playerList[self.currentPlayer].wheat -= 1
                self.playerList[self.currentPlayer].ore -= 1
                self.playerList[self.currentPlayer].sheep -= 1

                self.playerList[self.currentPlayer].addCard(self.deck.drawCard())

        

        #Use actions for the cards. Update variables, build things if you need to, set place for 
        def useKnight(self):
                cardList = self.playerList[self.currentPlayer].cards
                i = 0
                while cardList[i].type is not "Knight":
                        i += 1
                        if i is len(cardList):
                                i -= 1
                                break
                card = cardList[i]
                card.use(self.playerList[self.currentPlayer])
                self.deck.returnToDeck(card)
                self.playerList[self.currentPlayer].cards = cardList[0:i] \
                                                                                                         + cardList[i+1:-1]
                self.mode = Modes.Action

        def useMonopoly(self):
                cardList = self.playerList[self.currentPlayer].cards
                i = 0
                while cardList[i].type is not "Monopoly":
                        i += 1
                        if i is len(cardList):
                                i -= 1
                                break
                card = cardList[i]
                #card.use(self.playerList[self.currentPlayer])
                self.deck.returnToDeck(card)
                self.playerList[self.currentPlayer].cards = cardList[0:i] \
                                                                                                         + cardList[i+1:-1]

                self.mode = Modes.Monopoly

        
        def useYearofPlenty(self):
                cardList = self.playerList[self.currentPlayer].cards
                i = 0
                while cardList[i].type is not "YearOfPlenty":
                        i += 1
                        if i is len(cardList):
                                i -= 1
                                break
                card = cardList[i]
                self.deck.returnToDeck(card)
                self.playerList[self.currentPlayer].cards = cardList[0:i] \
                                                                                                         + cardList[i+1:-1]
                self.mode = Modes.Plenty

        def useRoadBuilder(self):
                cardList = self.playerList[self.currentPlayer].cards
                i = 0
                while cardList[i].type is not "Roadbuilder":
                        i += 1
                        if i is len(cardList):
                                i -= 1
                                break
                card = cardList[i]
                self.deck.returnToDeck(card)
                self.playerList[self.currentPlayer].cards = cardList[0:i] \
                                                                                                         + cardList[i+1:-1]
                self.mode = Modes.BuildRoad
                self.cardflag = 2                                                                                        

        def useWonder(self):
                cardList = self.playerList[self.currentPlayer].cards
                i = 0
                while cardList[i].type is not "WorldWonder":
                        i += 1
                        if i is len(cardList):
                                i -= 1
                                break
                card = cardList[i]
                self.playerList[self.currentPlayer].victoryPoints += 1
                self.deck.returnToDeck(card)
                self.playerList[self.currentPlayer].cards = cardList[0:i] \
                                                                                                         + cardList[i+1:-1]
                self.mode = Modes.Action

        


        #takes the map coordinates, makes the graph, edges, and puts the important things on the screen
        def loadMap(self, vertices, edges, resources, numbers):

                self.network = Graph()
                self.nodeToTile = dict()
                self.nodeToCoordinate = dict()
                self.coordinateToNode = dict()

                for i in vertices:
                        if i == "":
                                raise Exception ("What tf are you doin??")

                        self.network.addVertex(i[0]) 
                        self.nodeToTile[i[0]] = [] 
                        if i[3] is not 'None':
                                self.nodeToTile[i[0]].append(i[3])
                        if i[4] is not 'None':
                                self.nodeToTile[i[0]].append(i[4])
                        if i[5] is not 'None':
                                self.nodeToTile[i[0]].append(i[5])
                        self.nodeToCoordinate[i[0]] = (i[1], i[2])
                        self.coordinateToNode[(i[1], i[2])] = i[0]


                for x in edges:
                        self.network.addEdge(x)

                self.numbers = list(numbers)
                self.resourceCoords = resources
                self.tiles, self.resourceDictionary = \
                self.printToBoard(numbers, resources, self.screen)
                self.nodeContains = {node: None for node in self.network.vertices()}



        #draws everything else to the screen
        def draw(self):


                # fill in the background
                self.screen.fill(self.backgroundColour)

                # draw the game board
                self.screen.blit(self.board, (0,-50))

                numbers = list(self.numbers)
                self.printToBoard(numbers, self.resourceCoords, self.screen)


                # Update and draw the group contents 

                for road in self.road0:
                        pygame.draw.line(self.screen, 0xff2400, 
                                                         self.nodeToCoordinate[road[0]],
                                                         self.nodeToCoordinate[road[1]],
                                                         5)
                for road in self.road1:
                        pygame.draw.line(self.screen, 0x8ebbeb, 
                                                         self.nodeToCoordinate[road[0]],
                                                         self.nodeToCoordinate[road[1]],
                                                         5)
                for road in self.road2:
                        pygame.draw.line(self.screen, 0x800080  , 
                                                         self.nodeToCoordinate[road[0]],
                                                         self.nodeToCoordinate[road[1]],
                                                         5)

                for road in self.road3:
                        pygame.draw.line(self.screen, 0x00ff00, 
                                                         self.nodeToCoordinate[road[0]],
                                                         self.nodeToCoordinate[road[1]],
                                                         5)

                # draw settlements
                for node in self.activesettlements:
                        self.activesettlements[node].draw(self.screen)
                        
                # now cities
                for node in self.activecities:
                        self.activecities[node].draw(self.screen)



                # draw the status bar
                self.drawBar()

                # Draw the win message if necessary 
                if self.mode == Modes.GameOver:
                        windowText = "{} WINS!".format(
                                PLAYER_NAME[self.currentPlayer].upper())

                        # Render the text
                        windowMessage = BIG_FONT.render(
                                windowText,
                                True,
                                FONT_COLOUR)
                        # change position
                        messageRectangle = pygame.Rect((0, 0), windowMessage.get_size())
                        messageRectangle.center = (MAP_WIDTH / 2, self.screen.get_height() / 2)

                        # draw it
                        self.screen.blit(windowMessage, messageRectangle)

                # update the screen
                pygame.display.flip()

                # map has been drawn
                self.map = True

        
        def greaterThanZero(self):
                return (self.value > 0)

        def up1(self):
                self.value += 1

        def down1(self):
                self.value -= 1


        #handles the click and mode switching based on where game is clicked/large event handler
        def onClick(self, e):
                
                for player in self.playerList:
                        if self.playerList[player].victoryPoints >= 10:
                                winner = player
                                currentPlayer = player
                                self.mode = Modes.GameOver
                        

                nodeSelect = False
                # add any modes where clicks should have no effect
                if (self. mode is Modes.GameOver):
                        return 

                if (e.type is pygame.MOUSEBUTTONUP
                        and e.button is 1
                        and pygame.mouse.get_focused()):

                        # Insert code for clicking something that IS NOT IN THE MENU


                        #Mouse interaction
                        if e.pos[0] < 690:
                                # convert coords to node
                                node = self.clickToNode(e.pos)
                                if node is not None:
                                        nodeSelect = True
                                #is node selected?
                                if nodeSelect:
                                        #build a settlement - if you can build one at location
                                        if self.mode is Modes.BuildSettlement:
                                                if self.nodeContains[node] is None:
                                                        unoccupied = False
                                                        check = self.network.neighbours(node)
                                                        found = False
                                                        for x in check:
                                                               if self.nodeContains[x] is not None:
                                                                       found = True
                                                        if found is False:
                                                                unoccupied = True



                                                        if unoccupied is True:
                                                                self.createSettlement(node)

                                        elif self.mode is Modes.BuildCity:
                                                if self.nodeContains[node] == ('s', self.currentPlayer):
                                                        self.createCity(node)

                                        #gets first coordinate for road
                                        elif self.mode is Modes.BuildRoad:
                                                self.currentRoad1 = node
                                                self.mode = Modes.RoadInter

                                        #gets second coordinate for road and makes the road
                                        elif self.mode is Modes.RoadInter:
                                                self.currentRoad2 = node
                                                if not (self.currentRoad1, self.currentRoad2) in \
                                                   self.road0 and not \
                                                   (self.currentRoad1, self.currentRoad2) in self.road2 \
                                                   and not (self.currentRoad1, self.currentRoad2) \
                                                   in self.road3 and not \
                                                   (self.currentRoad1, self.currentRoad2) in self.road1 \
                                                   and \
                                                        not (self.currentRoad2, self.currentRoad1) in \
                                                   self.road0 and not \
                                                   (self.currentRoad2, self.currentRoad1) in self.road2 \
                                                   and not (self.currentRoad2, self.currentRoad1) \
                                                   in self.road3 and not \
                                                   (self.currentRoad2, self.currentRoad1) in self.road1:
                                                        canDo = False
                                                        if self.currentRoad1 != self.currentRoad2:
                                                                neighbours = self.network.neighbours(self.currentRoad1)
                                                                if self.currentRoad2 in neighbours:
                                                                        canDo = True
                                                        if canDo == True:

                                                                self.makeRoad(self.currentRoad1, self.currentRoad2)
                                                                self.currentRoad1, self.currentRoad2 = None, None
                                                                if self.hasStarted():
                                                                        self.mode = Modes.Action
                                                                elif self.cardflag > 0:
                                                                        self.mode = Modes.BuildRoad
                                                                else:
                                                                        self.endTurn()
                                                else:
                                                        self.currentRoad1 = None
                                                        self.currentRoad2 = None
                                                        self.mode = Modes.BuildRoad
                        
                        else:
                                #sets modes based on what is clicked and where the game is. Takes button, causes action of button to happen
                                if self.mode is Modes.Roll:
                                        button = self.rollButton
                                        if ((not button.condition or button.condition()) and 
                                                self.getButtonRectangle(button).collidepoint(e.pos)):
                                                button.onClick()
                                                self.resourceDistribution(self.dice)
                                                self.mode = Modes.RollDisplay

                                elif self.mode is Modes.RollDisplay:
                                        self.mode = Modes.Action

                                elif self.mode is Modes.Action:
                                        # Check which button was pressed
                                        for button in self.buttons:
                                                if ((not button.condition or button.condition()) and
                                                        self.getButtonRectangle(button).collidepoint(e.pos)):
                                                        button.onClick()

                                elif self.mode is Modes.Trade:
                                        for cat in self.tradewith:
                                                if ((not cat.condition or cat.condition()) and
                                                        self.getButtonRectangle(cat).collidepoint(e.pos)):
                                                        cat.onClick()

                                elif self.mode is Modes.ResSel1:
                                        for cat in self.resources1:
                                                if ((not cat.condition or cat.condition()) and
                                                        self.getButtonRectangle(cat).collidepoint(e.pos)):
                                                        cat.onClick()

                                elif self.mode is Modes.ResSel2:
                                        for cat in self.resources2:
                                                if ((not cat.condition or cat.condition()) and
                                                        self.getButtonRectangle(cat).collidepoint(e.pos)):
                                                        cat.onClick()

                                elif self.mode is Modes.ValSel1:
                                        for cat in self.numbers1:
                                                if ((not cat.condition or cat.condition()) and
                                                        self.getButtonRectangle(cat).collidepoint(e.pos)):
                                                        cat.onClick()

                                elif self.mode is Modes.ValSel2:
                                        for cat in self.numbers2:
                                                if ((not cat.condition or cat.condition()) and
                                                        self.getButtonRectangle(cat).collidepoint(e.pos)):
                                                        cat.onClick()

                                elif self.mode is Modes.YesNo:
                                        for cat in self.yesno:
                                                if ((not cat.condition or cat.condition()) and
                                                        self.getButtonRectangle(cat).collidepoint(e.pos)):
                                                        cat.onClick()

                                elif self.mode is Modes.Build:
                                        for button in self.construction:
                                                if ((not button.condition or button.condition()) and
                                                        self.getButtonRectangle(button).collidepoint(e.pos)):
                                                        button.onClick()

                                elif self.mode is Modes.BuildCard:
                                        for button in self.cardChoices:
                                                if ((not button.condition or button.condition()) and
                                                        self.getButtonRectangle(button).collidepoint(e.pos)):
                                                        button.onClick()

                                elif self.mode is Modes.InvtCheck:
                                        button = self.okayButton
                                        # then check if we clicked the okay button
                                        if ((not button.condition or button.condition()) and 
                                                self.getButtonRectangle(button).collidepoint(e.pos)):
                                                # change mode
                                                self.mode = Modes.Action

                                elif self.mode is Modes.Plenty:
                                        for button in self.plentyButtons:
                                                if ((not button.condition or button.condition()) and 
                                                        self.getButtonRectangle(button).collidepoint(e.pos)):
                                                        button.onClick()

                                elif self.mode is Modes.Monopoly:
                                        for button in self.monopoly_buttons:
                                                if ((not button.condition or button.condition()) and
                                                        self.getButtonRectangle(button).collidepoint(e.pos)):
                                                        button.onClick()

                                elif self.mode is Modes.UseCard:
                                        for button in self.usecards:
                                                if ((not button.condition or button.condition()) and
                                                        self.getButtonRectangle(button).collidepoint(e.pos)):
                                                        button.onClick()

                                elif self.mode is Modes.GameOver:
                                        button = self.gameOver
                                        if ((not button.condition or button.condition()) and 
                                                self.getButtonRectangle(button).collidepoint(e.pos)):
                                                button.onClick()


        #draws the bar and text for the gui
                #updates GUI bar based on the mode
        def drawBar(self):
                if not self.map:
                        return
                
                lineNumber = 0

                mouseposition = pygame.mouse.get_pos()
                barRect = self.barRectangle
                pygame.draw.rect(self.screen, BAR_COLOUR, barRect)

                outlineRect = self.barRectangle.copy()
                outlineRect.w -= 1
                outlineRect.h -= 1
                pygame.draw.rect(self.screen, OUTLINE_COLOUR, outlineRect, 2)
                modeString = None
                if self.mode is Modes.Roll:
                        modeString = 'Please Roll'
                elif self.mode is Modes.Action:
                        modeString = 'Choose Action'
                elif self.mode is Modes.RollDisplay:
                        modeString = 'Rolling Dice'
                elif self.mode is Modes.Trade:
                        modeString = 'With Which Player?'
                elif self.mode is Modes.ResSel1:
                        modeString = "From Your Resources?"
                elif self.mode is Modes.ResSel2:
                        modeString = "From Their Resources?"
                elif self.mode is Modes.ValSel1:
                        modeString = "How much " + self.tradeHolder1['resourceType'] + "?"
                elif self.mode is Modes.ValSel2:
                        modeString = "How much " + self.tradeHolder2['resourceType'] + "?"
                elif self.mode is Modes.YesNo:
                        modeString = "Sound good " + PLAYER_NAME[self.sendTo] + "?"
                elif self.mode is Modes.Build:
                        modeString = "What to build?"
                elif self.mode is Modes.BuildCity \
                         or self.mode is Modes.BuildSettlement:
                        modeString = "Where?"
                elif self.mode is Modes.BuildRoad or self.mode is Modes.RoadInter:
                        modeString = "Build a Road"
                elif self.mode is Modes.BuildCard:
                        modeString = "Buy or use?"
                elif self.mode is Modes.InvtCheck:
                        modeString = "Your Inventory:"
                        self.drawInventory()
                elif self.mode is Modes.UseCard:
                        modeString = "Which Card?"
                elif self.mode is Modes.Plenty:
                        modeString = "What type?"
                elif self.mode is Modes.Monopoly:
                        modeString = "What do you want to control?"
                elif self.mode is Modes.GameOver:
                        modeString = "GAME OVER " + PLAYER_NAME[self.currentPlayer] + " WINS!"

                self.drawBarTitle(
                        "{}'s turn!".format(PLAYER_NAME[self.currentPlayer]),
                        lineNumber)
                lineNumber += 1
                self.drawBarTitle("{}".format(modeString), lineNumber)
                lineNumber += 1

                if self.mode is Modes.BuildRoad or self.mode is Modes.RoadInter:
                        self.drawBarTitle("From where to where?", lineNumber)
                        lineNumber += 1

                #divider
                self.drawBarDivideLine(lineNumber)
                lineNumber += 1

                if self.mode is Modes.YesNo:
                        self.drawBarText(PLAYER_NAME[self.currentPlayer] + " gives up:",
                                                           lineNumber)
                        lineNumber += 1
                        self.drawBarText(str(self.tradeHolder1['number']) + " of " +
                                                           self.tradeHolder1['resourceType'], lineNumber)
                        lineNumber += 1
                        self.drawBarText(PLAYER_NAME[self.sendTo] + " gives up:",
                                                           lineNumber)
                        lineNumber += 1
                        self.drawBarText(str(self.tradeHolder2['number']) + " of " +
                                                           self.tradeHolder2['resourceType'], lineNumber)

                if self.mode is Modes.ValSel1 or self.mode is Modes.ValSel2:
                        self.drawBarText("Current Value: " + str(self.value), lineNumber)
                        lineNumber += 1
                        self.drawBarDivideLine(lineNumber)
                        lineNumber += 1

                if self.mode is Modes.Roll:
                        self.drawBarButton(self.rollButton)

                elif self.mode is Modes.RollDisplay:
                        self.drawBarTitle("You rolled a: " + str(self.dice), lineNumber)
                        lineNumber += 1
                        self.drawBarButton(self.okayButton)
                
                elif self.mode is Modes.Action:
                        for button in self.buttons:
                                self.drawBarButton(button)

                elif self.mode is Modes.Trade:
                        for player in self.tradewith:
                                self.drawBarButton(player)

                elif self.mode is Modes.ResSel1:
                        for resource in self.resources1:
                                self.drawBarButton(resource)

                elif self.mode is Modes.ResSel2:
                        for resource in self.resources2:
                                self.drawBarButton(resource)

                elif self.mode is Modes.ValSel1:
                        for choice in self.numbers1:
                                self.drawBarButton(choice)

                elif self.mode is Modes.ValSel2:
                        for choice in self.numbers2:
                                self.drawBarButton(choice)

                elif self.mode is Modes.YesNo:
                        for choice in self.yesno:
                                self.drawBarButton(choice)

                elif self.mode is Modes.Build:
                        for building in self.construction:
                                self.drawBarButton(building)

                elif self.mode is Modes.BuildCard:
                        for button in self.cardChoices:
                                self.drawBarButton(button)

                elif self.mode is Modes.InvtCheck:
                        self.drawBarButton(self.okayButton)

                elif self.mode is Modes.UseCard:
                        for button in self.usecards:
                                self.drawBarButton(button)

                elif self.mode is Modes.Plenty:
                        for button in self.plentyButtons:
                                self.drawBarButton(button)

                elif self.mode is Modes.Monopoly:
                        for button in self.monopoly_buttons:
                                self.drawBarButton(button)

                elif self.mode is Modes.GameOver:
                        self.drawBarButton(self.gameOver)
        
        
        def drawBarText(self, text, lineNumber):
                line_text = FONT.render(text, True, FONT_COLOUR)
                self.screen.blit(
                        line_text,
                        (self.barRectangle.x + PAD, FONT_SIZE * lineNumber + PAD))

        #makes title of bar
        def drawBarTitle(self, text, lineNumber):
                titleText = FONT.render(text, True, FONT_COLOUR)
                self.screen.blit(
                        titleText,
                        (self.barRectangle.centerx - (titleText.get_width()/2),
                        FONT_SIZE * lineNumber + PAD))
                
        #draws line between menu and map
        def drawBarDivideLine(self, lineNumber):
                y = FONT_SIZE * lineNumber + FONT_SIZE//2 + PAD
                pygame.draw.line(
                        self.screen,
                        (50, 50, 50),
                        (self.barRectangle.x, y),
                        (self.barRectangle.right, y))

        #Adds roads to list for player, draws roads to screen, and handles reason roads are being built
        def makeRoad(self, v1, v2):
                player = self.currentPlayer
                if player == 0:
                        self.road0.append((v1, v2))
                elif player == 1:
                        self.road1.append((v1, v2))
                elif player == 2:
                        self.road2.append((v1, v2))
                elif player == 3:
                        self.road3.append((v1, v2))

                if self.hasStarted() and self.cardflag is 0:
                        player = self.playerList[self.currentPlayer]
                        player.brick -= 1
                        player.wood -= 1
                if self.cardflag != 0:
                        self.cardflag = 0

        #gets location of button and rectangle 
        def getButtonRectangle(self, button):
                y = self.screen.get_height() - BUTTON_HEIGHT * (button.slot + 1)
                return pygame.Rect(self.barRectangle.x,
                                                        y,
                                                        self.barRectangle.width,
                                                        BUTTON_HEIGHT)
        #creates bar buttons for menus
        def drawBarButton(self, button):
                buttonRectangle = self.getButtonRectangle(button)
                buttonOuterRectangle = buttonRectangle
                buttonOuterRectangle.width -= 1
                buttonColour = BAR_COLOUR
                if button.condition and not button.condition():
                        buttonColour = BUTTON_DISABLED_COLOUR
                else:
                        mouseposition = pygame.mouse.get_pos()
                        if buttonRectangle.collidepoint(mouseposition):
                                buttonColour = BUTTON_HIGHLIGHT_COLOUR
                
                pygame.draw.rect(self.screen, buttonColour, buttonRectangle)
                pygame.draw.rect(self.screen, OUTLINE_COLOUR, buttonOuterRectangle, 2)
                buttonText = FONT.render(button.text, True, FONT_COLOUR)
                self.screen.blit(
                        buttonText,
                        (self.barRectangle.centerx - (buttonText.get_width()/2),
                        buttonRectangle.y + (BUTTON_HEIGHT//2) - buttonText.get_height()//2))

        #draws inventory to screen when selected during turn
        def drawInventory(self):
                playerObject = self.playerList[self.currentPlayer] # get player obj
                lineNumber = 3 # starting point
                self.drawBarText("Victory Points: " + str(playerObject.victoryPoints), lineNumber)
                lineNumber += 1
                self.drawBarText("Army Size: " + str(playerObject.armysize), lineNumber)
                lineNumber += 1
                self.drawBarDivideLine(lineNumber)
                lineNumber += 1
                self.drawBarText("Resources: ", lineNumber)
                lineNumber += 1
                self.drawBarText("Wheat: " + str(playerObject.wheat), lineNumber)
                lineNumber += 1
                self.drawBarText("Wood: " + str(playerObject.wood), lineNumber)
                lineNumber += 1
                self.drawBarText("Brick: " + str(playerObject.brick), lineNumber)
                lineNumber += 1
                self.drawBarText("ore: " + str(playerObject.ore), lineNumber)
                lineNumber += 1
                self.drawBarText("Sheep: " + str(playerObject.sheep), lineNumber)
                lineNumber += 1
                self.drawBarDivideLine(lineNumber)
                lineNumber += 1
                self.drawBarText("Construction: ", lineNumber)
                lineNumber += 1
                self.drawBarText("# Settlements: " + str(playerObject.settlements), lineNumber)
                lineNumber += 1
                self.drawBarText("# Cities: " + str(playerObject.cities), lineNumber)
                lineNumber += 1
                self.drawBarDivideLine(lineNumber)
                lineNumber += 1
                self.drawBarText("Cards: ", lineNumber)
                lineNumber += 1
                self.drawBarText("# cards: " + str(len(playerObject.cards)), lineNumber)

        #finds closest node from click
                #sourced from here, especially formula: https://stackoverflow.com/questions/45127141/find-the-nearest-point-in-distance-for-all-the-points-in-the-dataset-python :
        def clickToNode(self, pos):
                x1 = pos[0]
                y1 = pos[1]
                
                mainDistance = 10000
                
                for (x2, y2) in self.coordinateToNode:
                        interDistance = abs(x2-x1) + abs(y2-y1)
                        if interDistance < mainDistance:
                                (x3, y3) = (x2, y2)
                                mainDistance = interDistance
                if mainDistance > 25:
                        return None
                else:
                        return self.coordinateToNode[(x3, y3)]



        #takes help of helper methods for getting input from both players and allocating resources traded
        def performTrade(self, firstPlayer, secondPlayer):
                #What is first player trading?
                if self.tradeHolder1['resourceType'] is 'ore':
                        self.playerList[firstPlayer].ore -= self.tradeHolder1['number']
                elif self.tradeHolder1['resourceType'] is 'wheat':
                        self.playerList[firstPlayer].wheat -= self.tradeHolder1['number']
                elif self.tradeHolder1['resourceType'] is 'wood':
                        self.playerList[firstPlayer].wood -= self.tradeHolder1['number']
                elif self.tradeHolder1['resourceType'] is 'sheep':
                        self.playerList[firstPlayer].sheep -= self.tradeHolder1['number']
                elif self.tradeHolder1['resourceType'] is 'brick':
                        self.playerList[firstPlayer].brick -= self.tradeHolder1['number']

                # and what is the first player gaining? 
                if self.tradeHolder2['resourceType'] is 'ore':
                        self.playerList[firstPlayer].ore += self.tradeHolder2['number']
                elif self.tradeHolder2['resourceType'] is 'wheat':
                        self.playerList[firstPlayer].wheat += self.tradeHolder2['number']
                elif self.tradeHolder2['resourceType'] is 'wood':
                        self.playerList[firstPlayer].wood += self.tradeHolder2['number']
                elif self.tradeHolder2['resourceType'] is 'sheep':
                        self.playerList[firstPlayer].sheep += self.tradeHolder2['number']
                elif self.tradeHolder2['resourceType'] is 'brick':
                        self.playerList[firstPlayer].brick += self.tradeHolder2['number']

                # what is second player giving up? 
                if self.tradeHolder2['resourceType'] is 'ore':
                        self.playerList[secondPlayer].ore -= self.tradeHolder2['number']
                elif self.tradeHolder2['resourceType'] is 'wheat':
                        self.playerList[secondPlayer].wheat -= self.tradeHolder2['number']
                elif self.tradeHolder2['resourceType'] is 'wood':
                        self.playerList[secondPlayer].wood -= self.tradeHolder2['number']
                elif self.tradeHolder2['resourceType'] is 'sheep':
                        self.playerList[secondPlayer].sheep -= self.tradeHolder2['number']
                elif self.tradeHolder2['resourceType'] is 'brick':
                        self.playerList[secondPlayer].brick -= self.tradeHolder2['number']

                # and what is the second player gaining? 
                if self.tradeHolder1['resourceType'] is 'ore':
                        self.playerList[secondPlayer].ore += self.tradeHolder1['number']
                elif self.tradeHolder1['resourceType'] is 'wheat':
                        self.playerList[secondPlayer].wheat += self.tradeHolder1['number']
                elif self.tradeHolder1['resourceType'] is 'wood':
                        self.playerList[secondPlayer].wood += self.tradeHolder1['number']
                elif self.tradeHolder1['resourceType'] is 'sheep':
                        self.playerList[secondPlayer].sheep += self.tradeHolder1['number']
                elif self.tradeHolder1['resourceType'] is 'brick':
                        self.playerList[secondPlayer].brick += self.tradeHolder1['number']



                # reset stuff
                self.value = 0
                self.tradeHolder1['number'] = 0
                self.tradeHolder2['number'] = 0
                self.tradeHolder1['resourceType'] = None
                self.tradeHolder2['resourceType'] = None
                self.sendTo = None
                self.mode = Modes.Action

        #Method for creating settlement and adding it to lists
        def createSettlement(self, node):

                newSettlement = Settlement(self.playerList[self.currentPlayer], 
                                           self.nodeToCoordinate[node])
                self.activesettlements[node] = newSettlement

                self.nodeContains[node] = ('s', self.currentPlayer)
                self.activeNodes.append(node)
                if self.hasStarted():
                        self.mode = Modes.Action
                        self.playerList[self.currentPlayer].brick -= 1
                        self.playerList[self.currentPlayer].wood -= 1
                        self.playerList[self.currentPlayer].sheep -= 1
                        self.playerList[self.currentPlayer].wheat -= 1
                else:
                        self.mode = Modes.BuildRoad


        #method for creating cities, destroying settlements, and adding to lists
        def createCity(self, node):
                self.activesettlements[node].tornDown = True
                self.playerList[self.currentPlayer].ore -= 3
                self.playerList[self.currentPlayer].wheat -= 2
                self.playerList[self.currentPlayer].settlements -= 1


                self.activeNodes.append(node)
                self.nodeContains[node] = ('c', self.currentPlayer)
                newCity = City(self.playerList[self.currentPlayer], 
                                                self.nodeToCoordinate[node])
                self.activecities[node] = newCity

                self.mode = Modes.Action

        # allocates resources after the roll of the dice
        def resourceDistribution(self, rollDice):
                outerloop = 0
                innerloop = 0
                
                for node in self.nodeContains:
                        add = 0
                        outerloop += 1

                        if self.nodeContains[node] is not None:


                                letters = self.nodeToTile[node]
                                if len(letters) != 0:

                                        for letter in letters:
                                                innerloop += 1
                                                if letter == None:
                                                        pass
                                                else:
                                                        #print(letter)
                                                        resource = self.resourceDictionary[letter]
                                                        
                                                        if self.tiles[letter] == rollDice:
                                                                if self.nodeContains[node] is not None:
                                                                        playerStats = self.nodeContains[node]
                                                                        playerNumber = playerStats[1]
                                                                        if playerStats[0] == 's':
                                                                                add = 1
                                                                        
                                                                        if playerStats[0] == 'c':
                                                                                add = 2
                                                                                
                                                                        if resource == 'wheat':
                                                                                self.playerList[playerNumber].wheat += add
                                                                        if resource == 'brick':
                                                                                self.playerList[playerNumber].brick += add
                                                                        if resource == 'ore':
                                                                                self.playerList[playerNumber].ore += add
                                                                        if resource == 'wood':
                                                                                self.playerList[playerNumber].wood += add
                                                                        if resource == 'sheep':
                                                                                self.playerList[playerNumber].sheep += add



        """

             #####   Helper functions from here down ###
        """

        """
                Trade helper methods
        """

        #Trading helper functions - gets resource types and moves modes
        def tradewood1(self):
                self.tradeHolder1['resourceType'] = 'wood'
                self.mode = Modes.ValSel1

        def tradewheat1(self):
                self.tradeHolder1['resourceType'] = 'wheat'
                self.mode = Modes.ValSel1

        def tradebrick1(self):
                self.tradeHolder1['resourceType'] = 'brick'
                self.mode = Modes.ValSel1

        def tradesheep1(self):
                self.tradeHolder1['resourceType'] = 'sheep'
                self.mode = Modes.ValSel1

        def tradeore1(self):
                self.tradeHolder1['resourceType'] = 'ore'
                self.mode = Modes.ValSel1

        def tradewood2(self):
                self.tradeHolder2['resourceType'] = 'wood'
                self.mode = Modes.ValSel2

        def tradewheat2(self):
                self.tradeHolder2['resourceType'] = 'wheat'
                self.mode = Modes.ValSel2

        def tradebrick2(self):
                self.tradeHolder2['resourceType'] = 'brick'
                self.mode = Modes.ValSel2

        def tradesheep2(self):
                self.tradeHolder2['resourceType'] = 'sheep'
                self.mode = Modes.ValSel2

        def tradeore2(self):
                self.tradeHolder2['resourceType'] = 'ore'
                self.mode = Modes.ValSel2

        def gtfo(self):
                quit()

        def proposeTrade(self):
                '''
                Changes to Trade mode   
                '''
                self.mode = Modes.Trade


        #helper function to take who is active, propose trades, and function with the work
        def canTradeA(self):
                a = (self.currentPlayer == 0)
                return not a

        def canTradeB(self):
                a = (self.currentPlayer == 1)
                return not a

        def canTradeC(self):
                a = (self.currentPlayer == 2)
                return not a

        def canTradeD(self):
                a = (self.currentPlayer == 3)
                return not a

        def done1(self):
                self.tradeHolder1['number'] = self.value
                self.value = 0 # reset value
                self.mode = Modes.ResSel2

        def done2(self):
                self.tradeHolder2['number'] = self.value
                self.value = 0 # reset value
                self.mode = Modes.YesNo

        def yesway(self):
                self.performTrade(self.currentPlayer, self.sendTo)

        def noway(self):
                self.value = 0
                self.tradeHolder1['number'] = 0
                self.tradeHolder2['number'] = 0
                self.tradeHolder1['resourceType'] = None
                self.tradeHolder2['resourceType'] = None
                self.sendTo = None
                self.mode = Modes.Action


        """
                Card Helper Methods
        """

        #switch to buy card mode
        def cardmode(self):
                self.mode = Modes.BuildCard


        #helper method to switch mode to use card
        def useCard(self):
                self.mode = Modes.UseCard

        #helper functions to tell if player has a card to be used when drawing cards
        def hasKnight(self):
                for card in self.playerList[self.currentPlayer].cards:
                        if card.type == "Knight":
                                return True
                return False

        def hasYearOfPlenty(self):
                for card in self.playerList[self.currentPlayer].cards:
                        if card.type == "Year of Plenty":
                                return True
                return False

        def hasMonopoly(self):
                for card in self.playerList[self.currentPlayer].cards:
                        if card.type == "Monopoly":
                                return True
                return False

        def hasRoadBuilder(self):
                for card in self.playerList[self.currentPlayer].cards:
                        if card.type == "Roadbuilder":
                                return True
                return False

        def hasWonder(self):
                for card in self.playerList[self.currentPlayer].cards:
                        if card.type == "WorldWonder":
                                return True
                return False



        #methods for adding year of plenty resources to players
        def plentywood(self):
                self.playerList[self.currentPlayer].wood += 2
                self.mode = Modes.Action
        
        def plentysheep(self):
                self.playerList[self.currentPlayer].sheep += 2
                self.mode = Modes.Action

        def plentywheat(self):
                self.playerList[self.currentPlayer].wheat += 2
                self.mode = Modes.Action

        def plentybrick(self):
                self.playerList[self.currentPlayer].brick += 2
                self.mode = Modes.Action

        def plentyore(self):
                self.playerList[self.currentPlayer].ore += 2
                self.mode = Modes.Action



        #classes for setting the monopolies on wood - give resources to current player, then return to turn mode
        def monopolywood(self):
                for players in self.playerList:
                        if self.playerList[players] != self.playerList[self.currentPlayer]:
                                self.playerList[self.currentPlayer].wood += self.playerList[players].wood
                                self.playerList[players].wood = 0
                self.mode = Modes.Action
 
        def monopolybrick(self):
                for players in self.playerList:
                        if self.playerList[players] != self.playerList[self.currentPlayer]:
                                self.playerList[self.currentPlayer].brick += self.playerList[players].brick
                                self.playerList[players].brick = 0
                self.mode = Modes.Action

        def monopolywheat(self):
                for players in self.playerList:
                        if self.playerList[players] != self.playerList[self.currentPlayer]:
                                self.playerList[self.currentPlayer].wheat += self.playerList[players].wheat
                                self.playerList[players].wheat = 0
                self.modes = Modes.Action

        def monopolysheep(self):
                for players in self.playerList:
                        if self.playerList[players] != self.playerList[self.currentPlayer]:
                                self.playerList[self.currentPlayer].sheep += self.playerList[players].sheep
                                self.playerList[players].sheep = 0
                self.mode = Modes.Action

        def monopolyore(self):
                for players in self.playerList:
                        if self.playerList[players] != self.playerList[self.currentPlayer]:
                                self.playerList[self.currentPlayer].ore += self.playerList[players].ore
                                self.playerList[players].ore = 0
                self.mode = Modes.action

        #draws last tiles to board based on tiles for dice rolling and resource distribution
        def printToBoard(self, numbers, resourcesList, screen):
                i = 0
                tiles = dict()
                resources = dict()


                for x in resourcesList:
                        # base string manipulation
                        line = x
                        # find the coordinates for the image
                        xcor = int(line[0])
                        ycor = int(line[1])
                        # remove the used number from list
                        number = numbers.pop()

                        # determines what number it is
                        # and loads the appropriate image
                        if number == 2:
                                two = pygame.image.load('imgs/2.jpg')
                                screen.blit(two, (xcor, ycor))

                        if number == 3:
                                three = pygame.image.load('imgs/3.jpg')
                                screen.blit(three, (xcor, ycor))

                        if number == 4:
                                four = pygame.image.load('imgs/4.jpg')
                                screen.blit(four, (xcor, ycor))

                        if number == 5:
                                five = pygame.image.load('imgs/5.jpg')
                                screen.blit(five, (xcor, ycor))

                        if number == 6:
                                six = pygame.image.load('imgs/6.jpg')
                                screen.blit(six, (xcor, ycor))

                        if number == 8:
                                eight = pygame.image.load('imgs/8.jpg')
                                screen.blit(eight, (xcor, ycor))

                        if number == 9:
                                nine = pygame.image.load('imgs/9.jpg')
                                screen.blit(nine, (xcor, ycor))

                        if number == 10:
                                ten = pygame.image.load('imgs/10.jpg')
                                screen.blit(ten, (xcor, ycor))

                        if number == 11:
                                eleven = pygame.image.load('imgs/11.jpg')
                                screen.blit(eleven, (xcor, ycor))

                        if number == 12:
                                twelve = pygame.image.load('imgs/12.jpg')
                                screen.blit(twelve, (xcor, ycor))

                        # assigns number and letter for a tile
                        if i == 0:
                                tiles['P'] = number
                                resources['P'] = 'wood' 
                        if i == 1:
                                tiles['Q'] = number
                                resources['Q'] = 'sheep'
                        if i == 2:
                                tiles['R'] = number 
                                resources['R'] = 'wheat'
                        if i == 3:
                                tiles['O'] = number
                                resources['O'] = 'brick'
                        if i == 4:
                                tiles['N'] = number
                                resources['N'] = 'ore'
                        if i == 5: 
                                tiles['M'] = number
                                resources['M'] = 'brick'
                        if i == 6:
                                tiles['L'] = number
                                resources['L'] = 'sheep'
                        if i == 7:
                                tiles['H'] = number 
                                resources['H'] = 'wood'
                        if i == 8:
                                tiles['I'] = number
                                resources['I'] = 'wheat'
                        if i == 9:
                                tiles['J'] = number
                                resources['J'] = 'wood'
                        if i == 10:
                                tiles['K'] = number
                                resources['K'] = 'wheat'
                        if i == 11:
                                tiles['G'] = number
                                resources['G'] = 'brick'
                        if i == 12:
                                tiles['F'] = number
                                resources['F'] = 'sheep'
                        if i == 13:
                                tiles['E'] = number
                                resources['E'] = 'sheep'
                        if i == 14:
                                tiles['D'] = number
                                resources['D'] = 'ore'
                        if i == 15:
                                tiles['A'] = number
                                resources['A'] = 'ore'
                        if i == 16:
                                tiles['B'] = number
                                resources['B'] = 'wheat'
                        if i == 17:
                                tiles['C'] = number
                                resources['C'] = 'wood'

                        i += 1
                return tiles, resources 
                                                                                
