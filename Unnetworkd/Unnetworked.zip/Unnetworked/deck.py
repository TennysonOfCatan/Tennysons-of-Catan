"""THIS IS THE DECK CLASS"""

import random

#establishes card object "Year of Plenty"
class YearOfPlenty:

        def __init__(self):
                self.type = "YearOfPlenty"

        def __eq__(self, q):
                return q == self.type

        def __str__(self):
                return "Year of Plenty"

#establishes card object "Monopoly"
class Monopoly:

        def __init__(self):

                self.type = "Monopoly"

        def __str__(self):
                return "Monopoly"

#establishes card object "Knight"
class Knight:

        def __init__(self):
                self.type = "Knight"

        def use(self, player):
                player.armySize += 1

        def __str__(self):
                return "Knight"

#establishes card object "Road Rebuilder"
class Roadbuilder:

        def __init__(self):
                self.type = "Roadbuilder"
        def __str__(self):
                return "Road Builder"

#establishes card object "World Wonder"
class WorldWonder:

        def __init__(self):
                self.type = "WorldWonder"

        def vp(self, player):
                player.victoryPoints += 1 

        def __str__(self):
                return "World Wonder"

#establishes a deck object/instantiated with two arrays: cards and used (cards)
class Deck():

        #ref for number of cards, cost of building, etc: https://boardgamegeek.com/thread/324667/counts-components-settlers-catan-4th-edition
        def __init__(self):
                self.cards = []
                self.used = []
                #each for-loop iterates to add a certain number of each card to the cards deck
                for i in range(0, 14):
                        knight = Knight()
                        self.cards.append(knight)

                for i in range (0, 2):
                        monopoly = Monopoly()
                        self.cards.append(monopoly)

                for i in range (0, 2):
                        year = YearOfPlenty()
                        self.cards.append(year)

                for i in range (0, 2):
                        road = Roadbuilder()
                        self.cards.append(road)

                for i in range (0, 5):
                        wonder = WorldWonder()
                        self.cards.append(wonder)
                        
        #a shuffle function used to shuffle the deck, used with importing random
        def shuffle(self):
                random.shuffle(self.cards)


        #returns a used card to the deck
        def returnToDeck(self, card):
                self.used.append(card)

        '''first tests to see if current deck is empty;
        if so, the cards in the used deck are each popped 
        and appended to the player deck, then shuffled'''
        def drawCard(self):
                if len(self.cards) is 0:
                        for i in self.used:
                                self.cards.append(i)
                                self.used.remove(i)
                        self.shuffle()
                card = self.cards.pop()
                return card
                #card placeholder takes value of popped card, appends to used (card) deck and returns card drawn
