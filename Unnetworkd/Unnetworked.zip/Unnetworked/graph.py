import time
import random
import pygame
import networkx as nx

## this code was done by Beth Isbell
## refernce for this code comes from: https://www.python.org/doc/essays/graphs/
##and from: https://networkx.github.io/documentation/stable/reference/classes/graph.html
class Graph:

    ## constructor
    def __init__(self, vertices = set(), edges = list()):
        self.aList = dict()
        self.ngraph = nx.Graph()
        for v in vertices:
            self.ngraph.add_node(v)
        for e in edges:
            self.ngraph.add_edge(e)
    
    ## Adds a vertex
    def addVertex(self, v):
        self.ngraph.add_node(v)

    ## Adds an edge
    def addEdge(self, e):

        if not self.isVertex(e[0]) \
          or not self.isVertex(e[1]):
            raise ValueError("an endpoint is not in graph")
        v1 = e[0]
        v2 = e[1]

        self.ngraph.add_edge(v1,v2)

    ## checks if the given variable is a vertex
    def isVertex(self, v):

        return self.ngraph.has_node(v)

    ## checks if the given variable is an edge
    def isEdge(self, e):

        if e[0] not in self.ngraph:
            return False
        else:
            return e[1] in self.ngraph

    ## defines the neighbors of a vertex
    ## if the given vertex is not in the graph, return an error
    def neighbours(self, v):
        if not self.isVertex(v):
            raise ValueError("vertex not in graph")
        neighbours = []
        listthing = self.ngraph.neighbors(v)
        for i in listthing:
            neighbours.append(i)
        
        return neighbours

    ## defines the set of vertices in the graph
    def vertices(self):
        return self.ngraph.nodes()

    ## defines the set of edges in the graph
    def edges(self):
        e = self.ngraph.edges()
        return e


def isWalk(g, walk):
    if not walk:
        return False

    if len(walk) == 1:
        return g.isVertex(walk[0])
    for i in range(len(walk)-1):
        if not g.isEdge((walk[i], walk[i+1])):
            return False

    return True

def isPath(g, path):
    if len(set(path)) < len(path):
        return False
    return isWalk(g, path)

## searches for a given vertex within the graph
## if the vertex is not there, return an error
def search(g, v):
    if not g.isVertex(v):
        raise ValueError("vertex not in graph")

    reached = {v:v}
    stack = [v]
    while stack: 
        curr = stack.pop()
        for succ in g.neighbours(curr):
            if succ not in reached:
                reached[succ] = curr
                stack.append(succ)
    return reached


##  determine a path between two vertices
## return a list of vertices (including the start and end) comprising the path   
def findPath(g, start, end):
    reached = search(g, start)

    if end not in reached:
        return None

    path = [end]
    curr = end
    while curr != start:
        curr = reached[curr]
        path.append(curr)
    path.reverse()
    return path


## generates a random Graph
def randomGraph(n, m):   
    edges = [(random.randint(0,n-1),random.randint(0,n-1)) \
                 for i in range(m)]
    return Graph(set(range(n)), edges)


## finds which players has the largest army
## compares each player's army size to the other players' armies
def findLargestArmy(player, currentLargest, playerList):
	if currentLargest != None:
		largest = playerList[currentLargest].armySize
	else:
		largest = 2
	playerArmy = playerList[player].armySize
	if playerArmy > largest:
		if currentLargest == None:
			playerList[player].victoryPoints += 2
			return player
		if currentLargest != None:
			playerList[currentLargest].victoryPoints -= 2
			playerList[player].victoryPoints += 2
		return 
	return currentLargest


## put the edges into the graph
def populateEdges(graph, vertices):
	edges = []

	for v in vertices:
		neighbours = graph.neighbours(v)
		for neighbour in neighbours:
			edges.append((v, neighbour))
			edges.append((neighbour, v))

	return edges


## graphs the roads that the players build
def graphRoads(roads):
	network = Graph()
	for edge in roads:
		for vertex in edge:
			if not network.isVertex(vertex):
				network.addVertex(vertex)
		network.addEdge(edge)
		network.addEdge((edge[1], edge[0]))

	return network

## creates a set of all roads that a player has
def makeSet(roads, network):
	verticeList = network.vertices()
	verticeList = list(verticeList)
	verticeSegments = []
	while verticeList != []:
		randomVertice = verticeList.pop()
		segment = []
		segment.append(randomVertice)
		if verticeList != []:
			for vertice in verticeList:
				path = findPath(network, randomVertice, vertice)
				if path == None:
					pass
				else:
					segment.append(vertice)
			i = 1
			while i != len(segment):
				verticeList.remove(segment[i])
				i += 1
		
		verticeSegments.append(segment)
	return verticeSegments


	
def longestRoad(roads):
	
	#finds the longest road
        #code from here: http://stackoverflow.com/questions/3191460/finding-the-longest-road-in-a-settlers-of-catan-game-algorithmically
	
	network = graphRoads(roads)
	sets = makeSet(roads, network)

	if len(roads) < 1:
		return 0
	if len(roads) < 2:
		return 1
	network = graphRoads(roads)
	nodes = []
	for v in network.vertices():
		if len(network.neighbours(v)) == 1:
			nodes.append(v)
	if len(nodes) == 0:
		length = len(network.vertices())
		return length
	try:
		node = nodes[0]
		dest = nodes[1]
	except IndexError:
		return 1

	visited = dict()
	dist    = dict()

	length = 0

	Queue = list()
	Queue.append(((node, node), 0)) 

	while len(Queue) > 0:
		((prev, curr), val) = Queue.pop() 
		if curr not in visited.keys():
			visited[curr] = prev 
			dist[curr] = val 
			for succ in network.neighbours(curr):
				tempDistance = val + 1
				Queue.append(((curr, succ), tempDistance))
	vertex = dest 
	while vertex != node:
		length += 1 
		try:
			vertex = visited[vertex]
		except KeyError:
			break

	return length


## takes all of the edges and finds the starts of segments
def findStarts(edges, graph):

	startingPoints = []
	for e in edges:
		vertice1 = e[0]
		vertice2 = e[1]

		if len(graph.neighbours(vertice1)) == 1:
			if vertice1 not in startingPoints:
				startingPoints.append(vertice1)

		if len(graph.neighbours(vertice2)) == 1:
			if vertice2 not in startingPoints:
				startingPoints.append(vertice1)

	return startingPoints

