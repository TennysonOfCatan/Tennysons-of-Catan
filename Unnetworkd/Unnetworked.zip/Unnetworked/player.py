from deck import *
#establishes a main player object
class Player():

#player, throughout the game, will gain resources, all initially set to 0 unless given as a parameter
	def __init__(self, index, vp = 0, wheat = 0, ore = 0, brick = 0, sheep = 0,
		         wood = 0, settlements = 0, cities = 0, armysize = 0, longestroad = 0):
		self.victoryPoints = vp
		self.wheat = wheat
		self.wood = wood
		self.brick = brick
		self.ore = ore
		self.sheep = sheep
		self.settlements = settlements
		self.cities = cities
		self.armySize = armysize
		self.longestRoad = longestroad
		self.cards = []
		self.index = index
		if type(index) is not int:
			raise Exception("Index is not int")



        #getters
	def wheat(self):
		return self.wheat
	def wood(self):
		return self.wood
	def ore(self):
		return self.ore
	def sheep(self):
		return self.sheep
	def brick(self):
		return self.brick
	def settlements(self):
		return self.settlements
	def cities(self):
		return self.cities
	def victoryPoints(self):
		return self.victoryPoints
	def armysize(self):
		return self.armySize
	def longestroad(self):
		return self.longestRoad

	    

	def addCard(self, card):
		self.cards.append(card)


	#source for costs of all the buildings: https://boardgamegeek.com/thread/324667/counts-components-settlers-catan-4th-edition
	def buySettlement(self, location):
		if self.wood < 1 or self.brick < 1 or self.wheat < 1 or self.sheep < 1:
			raise Exception("Do not have sufficient resources")
		#tests to see if the player has enough of certain resources to buy a settlement
		else:
			self.wood -= 1
			self.brick -= 1
			self.wheat -= 1
			self.sheep -=1 
			self.settlements += 1
			self.victoryPoints += 1 
		#subtracts each of the necessary resources to obtain a settlement, adds to number of settlements and vp
	
	def buyCity(self, settlement):
		if self.ore < 3 or self.wheat < 2 or self.settlements is 0:
			raise Exception("Do not have sufficient resources or settlements")
		#tests to see if the player has enough of certain resources to buy a city
		else:
			self.ore -= 3
			self.wheat -= 2
			self.settlements -=1
			self.cities += 1
			self.victoryPoints += 1
		#subtracts each of the necessary resources to obtain a city

	def buyDevelopmentCard(self):
		if self.ore < 1 or self.wheat < 1 or self.sheep < 1:
			raise Exception("Do not have sufficient resources")
		#tests to see if the player has enough of certain resources to buy a dev card
		else:
			self.ore -= 1
			self.sheep -= 1
			self.wheat -= 1
			##########self.cards.append(cards)########## THIS IS WHAT IT WAS PREVIOUSLY
			self.cards.append(Deck.drawCard())
		#subtracts each of the necessary resources to add a dev card to player's current cards

	def buyRoad(self):

		if self.brick < 1 or self.wood < 1:
			raise Exception("Do not have sufficient resources")
		#tests to see if the player has enough of certain resources to buy a road
		else:
			self.brick -= 1
			self.wood -= 1
		#subtracts each of the necessary resources to buy a road
