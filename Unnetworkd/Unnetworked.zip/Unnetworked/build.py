import pygame
import player
from pygame.sprite import Sprite 

#Source: http://programarcadegames.com/index.php?chapter=introduction_to_sprites
#the other source: https://www.pygame.org/docs/ref/sprite.html


SIZE = 25
SIZE_ROAD = 100
        
class City(Sprite):

        # Constructor
        def __init__(self, player, pos):

                Sprite.__init__(self)
                # Set image for city depending on the player
                self.sprite = pygame.image.load("imgs/cit"+str(player.index)+".jpg")

                # Set city attributes and update VP counter
                self.type = "City"
                self.name = "City"
                self.rect = pygame.Rect(0, 0, SIZE, SIZE)
                self.x = int(pos[0] - 13)
                self.y = int(pos[1] - 13)
                self.position = (self.x, self.y)
                player.cities += 1
                player.victoryPoints += 1

        # Draw the city sprite onto the board
        def draw(self, screen):

                screen.blit(self.sprite, self.position)

class Road(Sprite):
        # Set image for road
        sprite = pygame.image.load("imgs/rd.jpg")

        # Constructor
        def __init__(self, player, tileX = None, tileY = None, angle = 0, **keywords):

                # Set road attributes
                self.image = Road.sprite

                Sprite.__init__(self)


                

                self.tileX = tileX
                self.tileY = tileY
                self.angle = angle

                

                self.type = "Road"
                self.name = "Road"
                self.rect = pygame.Rect(0,0, SIZE, SIZE_ROAD)

                self.image = pygame.transform.rotate(Road.sprite, self.angle)
                # Draw the road onto the game board
                def draw(self, screen):

                        screen.blit(self.sprite, self.position)




class Settlement(Sprite):

        # Constructor
        def __init__(self, player, pos):
                # Set image for settlement depending on the player
                self.sprite = pygame.image.load("imgs/set"+str(player.index)+".jpg")
                Sprite.__init__(self)

                # settlement attributes and VP counter update
                self.type = "Settlement"
                self.name = "Settlement"
                self.rect = pygame.Rect(0, 0, SIZE, SIZE)
                player.settlements += 1
                self.x = int(pos[0] - 13)
                self.y = int(pos[1] - 13)
                self.position = (self.x, self.y)
                self.tornDown = False

                player.victoryPoints += 1

        # Draw settlement onto game board and remove when city built
        def draw(self, screen):
                if self.tornDown:
                        return
                else:
                        screen.blit(self.sprite, self.position)






