import pygame
from pygame.sprite import Sprite


SIZE = 50

class BaseResource(Sprite):

	# Constructor initializes baseResource attributes
	def __init__(self, tileX = None, tileY = None, Number = None, **keywords):

		Sprite.__init__(self)
		self.number = number 

		# set requirements for pygame
		self.image = None
		self.rect = pygame.Rect(0, 0, SIZE, SIZE)
		self.brickUp = 0
		self.sheepUp = 0
		self.oreUp = 0
		self.wheatUp = 0
		self.woodUp = 0

		def getResourceRoll(roll):

			for r in baseResource.resources:
				if(roll) == number:
					return r

class Brick(BaseResource):

	#sprite = pygame.image.load("insert file name here")
	# Constructor
	def __init__(self, **keywords):
		super().__init__(**keywords)

		# specify resource
		self.type = "Brick"
		self.resourceChange1 = 1
		self.resourceChange2 = 2
		self.name = "Brick"


class Sheep(BaseResource):


	#sprite = pygame.image.load("insert file name here")
	# Constructor
	def __init__(self, **keywords):
		super().__init__(**keywords)
		#self.image = Sheep.sprite

		# specify resource
		self.type = "Sheep"
		self.resourceChange1 = 1
		self.resourceChange2 = 2
		self.name = "Sheep"


class ore(BaseResource):


	#sprite = pygame.image.load("insert file name here")
	# Constructor
	def __init__(self, **keywords):
		super().__init__(**keywords)
		#self.image = ore.sprite

		# specify resource
		self.type = "ore"
		self.resourceChange1 = 1
		self.resourceChange2 = 2
		self.name = "ore"

class Wheat(BaseResource):

	#sprite = pygame.image.load("insert file name here")
	# Constructor
	def __init__(self, **keywords):

		#load from base class
		super().__init__(**keywords)
		#self.image = Wheat.sprite

		# specify resource
		self.type = "Wheat"
		self.resourceChange1 = 1
		self.resourceChange2 = 2
		self.name = "Wheat"


class Wood(BaseResource):

	#sprite = pygame.image.load("insert file name here")
	# Constructor
	def __init__(self, **keywords):
		super().__init__(**keywords)
		#self.image = Wood.sprite

		# specify resource
		self.type = "Wood"
		self.resourceChange1 = 1
		self.resourceChange2 = 2
		self.name = "Wood"


