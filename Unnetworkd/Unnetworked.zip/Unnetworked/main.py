import sys, pygame 
import socket 
from _thread import *
import threading 
from gui import *
import random
RESOLUTION = pygame.Rect(0, 0, 911, 600)
backgroundColour = (0, 0, 0)

#makes random order of numbers for the gui
def randomOrder():
        numbers = [2, 3, 3, 4, 4, 5, 5, 6, 6, 8, 8, 9, 9, 10, 10, 11, 11, 12]
        random.shuffle(numbers)
        return numbers






# initialize
pygame.mixer.pre_init(22050, 16, 2, 512) 
pygame.init()
pygame.display.set_caption("Tennysons of Catan")
mainGUI = GUI(RESOLUTION, backgroundColour)
clock = pygame.time.Clock()
argv = sys.argv[1:]
numbers = randomOrder()
resourceCoords = [[230, 98], [329, 98], [433, 98], [180, 183], [280, 183], [380, 183], [480, 183], [230, 266], [330, 266], [435, 266],
                  [540, 266], [175, 363], [280, 363], [385, 363], [490, 365], [225, 453], [330, 453], [440, 453]]
nodeCoords = [[1, 450, 520, "C", None, None], [2, 500, 493, "C", None, None], [3, 500, 433, "C", "D", None], [4, 450, 405, "C", "D", "E"],
              [5, 395, 435, "B", "C", "E"], [6, 395, 490, "B", "C", None], [7, 345, 520, "B", None, None], [8, 345, 405, "B", "F", "E"],
              [9, 290, 435, "A", "B", "F"], [10, 290, 490, "A", "B", None], [11, 237, 520, "A", None, None], [12, 188, 490, "A", None, None],
              [13, 188, 430, "A", "G", None], [14, 235, 402, "A", "G", "F"], [15, 235, 340, "G", "F", "H"], [16, 190, 310, "G", "H", None],
              [17, 138, 340, "G", None, None], [18, 138, 398, "G", None, None], [19, 85, 307, None, None, None],
              [20, 85, 250, None, None, None], [21, 140, 221, "O", None, None], [22, 190, 249, "O", "H", None], [23, 237, 220, "O", "H", "N"],
              [24, 293, 252, "I", "H", "N"], [25, 292, 304, "H", "I", "F"], [26, 343, 340, "F", "E", "I"], [27, 398, 307, "I", "E", "J"],
              [28, 396, 251, "I", "J", "M"], [29, 344, 222, "N", "I", "M"], [30, 344, 162, "N", "M", "Q"], [31, 293, 130, "N", "P", "Q"],
              [32, 240, 160, "O", "P", "N"], [33, 191, 132, "O", "P", None], [34, 139, 159, "O", None, None], [35, 191, 74, "P", None, None],
              [36, 239, 43, "P", None, None], [37, 292, 75, "P", "Q", None], [38, 345, 44, "Q", None, None], [39, 395, 76, "Q", "R", None],
              [40, 395, 131, "Q", "R", "M"], [41, 450, 45, "R", None, None], [42, 449, 161, "R", "M", "L"], [43, 501, 131, "R", "L", "M"],
              [44, 449, 219, "M", "L", "J"], [45, 499, 250, "J", "L", "K"], [46, 550, 162, "L", None, None], [47, 550, 219, "L", "K", None],
              [48, 604, 253, "K", None, None], [49, 603, 310, "K", None, None], [50, 552, 342, "D", "K", None], [51, 497, 311, "D", "J", "K"],
              [52, 448, 337, "D", "J", "E"], [53, 550, 398, "D", None, None], [54, 501, 75, "R", None, None]] 
edgeCoords = [[1, 2], [1, 6], [2, 3], [2, 1], [3, 53], [3, 4], [3, 2], [4, 3], [4, 5], [4, 52], [5, 4], [5, 8], [5, 6], [6, 7], [6, 1], [6, 5],
              [7, 6], [7, 10], [8, 5], [8, 9], [8, 26], [9, 8], [9, 10], [9, 14], [10, 11], [10, 7], [10, 9], [11, 10], [11, 12], [12, 11],
              [12, 13], [13, 14], [13, 18], [13, 12], [14, 13], [14, 9], [14, 15], [15, 16], [15, 14], [15, 25], [16, 22], [16, 15], [16, 17],
              [17, 16], [17, 18], [17, 19], [18, 17], [18, 13], [19, 20], [19, 17], [20, 21], [20, 19], [21, 22], [21, 34], [21, 20], [22, 16],
              [22, 21], [22, 23], [23, 22], [23, 24], [23, 32], [24, 25], [24, 23], [24, 25], [25, 24], [25, 26], [25, 15], [26, 25], [26, 27],
              [26, 8], [27, 26], [27, 28], [27, 52], [28, 29], [28, 27], [28, 44], [29, 28], [29, 24], [29, 30], [30, 29], [30, 31], [30, 40],
              [31, 30], [31, 32], [31, 37], [32, 31], [32, 23], [32, 33], [33, 32], [33, 34], [33, 35], [34, 33], [34, 21], [35, 33], [35, 36],
              [36, 35], [36, 37], [37, 31], [37, 36], [37, 38], [38, 37], [38, 39], [39, 41], [39, 38], [39, 40], [40, 39], [40, 42], [40, 30],
              [41, 39], [41, 54], [42, 40], [42, 43], [42, 44], [43, 42], [43, 46], [43, 54], [44, 42], [44, 45], [44, 28], [45, 47], [45, 44],
              [45, 51], [46, 47], [46, 43], [47, 46], [47, 48], [47, 45], [48, 47], [48, 49], [49, 48], [49, 50], [50, 49], [50, 51], [50, 53],
              [51, 50], [51, 52], [51, 45], [52, 4], [52, 27], [52, 51], [53, 50], [53, 3], [54, 41], [54, 43]]
mainGUI.loadMap(nodeCoords, edgeCoords, resourceCoords, numbers)

def thread(c):
                
        turn = "It's player A's turn"
        data = turn.encode('ascii')
        c.send(data)
        time.sleep(60)
        c.close()

"""
print_lock = threading.Lock()
host = ""
port = 12345
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((host, port)) 
print("socket binded to port", port)
s.listen(5) 
print("socket is listening")
"""
mainGUI.update()
mainGUI.draw()
#handle event clicks and closing program, later to become the distributed main class with Dask Distributed
#once this is integrated with Trinket.IO
while True:
        #c, addr = s.accept()
        #print_lock.acquire()
        #print('Connected to :', addr[0], ':', addr[1]) 
        
        
        for event in pygame.event.get():
                if event.type is pygame.QUIT:
                        pygame.display.quit()
                        sys.exit()
                
                elif (event.type is pygame.KEYDOWN and (event.key is pygame.K_ESCAPE)):
                        pygame.display.quit()
                        sys.exit()
                
                elif (event.type is pygame.KEYDOWN and (event.key is pygame.K_e)):
                        mainGUI.endTurn()
                
                elif event.type is pygame.MOUSEBUTTONUP:
                        mainGUI.onClick(event)
                        #print(pygame.mouse.get_pos())
         #               start_new_thread(thread, (c,))
        mainGUI.update()
        mainGUI.draw()
        clock.tick(60)

s.close()

